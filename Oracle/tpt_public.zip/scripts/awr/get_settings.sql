SELECT * FROM dba_hist_wr_control
@pr
