-- Parameter 1 [wrap|nowrap]
-- Parameter 2 Report title

@@htmlset2 &1 "&2" #f7f7e7 black
