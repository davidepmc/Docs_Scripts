prompt alter session set current_schema=&1
alter session set current_schema=&1;
