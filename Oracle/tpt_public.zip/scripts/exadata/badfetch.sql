SELECT /*+ MONITOR */ * FROM tanel.sales;

