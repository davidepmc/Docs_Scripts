spool off

host vi + &seminar_logfile

spool &seminar_logfile append

