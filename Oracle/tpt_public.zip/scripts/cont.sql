SELECT * FROM v$containers;

