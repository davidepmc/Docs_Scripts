SELECT * FROM v$buffer_pool;
