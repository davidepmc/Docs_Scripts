@@ed &trc
