SELECT * FROM v$diag_info;

