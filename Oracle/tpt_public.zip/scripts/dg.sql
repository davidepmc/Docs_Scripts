SELECT * FROM v$dataguard_config;
