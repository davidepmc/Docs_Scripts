host " doskey /history /exename=sqlplus.exe | grep -ni &1 | grep -iv ]@h "
